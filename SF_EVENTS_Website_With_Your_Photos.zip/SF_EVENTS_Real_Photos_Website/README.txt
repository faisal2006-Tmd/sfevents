SF EVENTS — WEBSITE WITH YOUR EVENT PHOTOS

1. Extract this ZIP file.
2. Keep the assets folder beside index.html.
3. Open index.html in Chrome.
4. Internet is still needed for Google Fonts and the 3D libraries (Three.js / GSAP).

Your uploaded wedding, engagement, birthday, corporate and decoration photographs are
included locally in assets/ and used in both the Portfolio and Gallery sections.

The photos are labelled INSPIRATION so visitors do not mistake reference imagery
for confirmed SF EVENTS client projects. Replace them with your own event photos
when you have completed projects.
